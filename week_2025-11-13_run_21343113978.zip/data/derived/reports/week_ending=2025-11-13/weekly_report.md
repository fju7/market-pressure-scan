# Weekly Market Pressure Report
**Week Ending:** 2025-11-13

This report ranks S&P 500 names by **Upside Pressure (UPS)** using weekly news novelty, event intensity, sentiment shift, and market confirmation. Use it as a **screen and context tool**, not as a standalone trading instruction.

## Signal quality snapshot
- Avg novelty (z): 0.00
- Avg event intensity (z): -0.00
- Avg price-action news rate: 0.54
- PRICE_ACTION_RECAP (% of clusters): 40%
- Sector mix (Top 20): Information Technology: 4, Financials: 3, Industrials: 2, Consumer Staples: 2, Utilities: 2, Health Care: 2, Communication Services: 1, Energy: 1, Real Estate: 1, Consumer Discretionary: 1, Materials: 1

## ⚠️ Low-information week
The system is seeing mostly market wrap / price-move recap content rather than company-specific events. Treat UPS/DPS rankings as *low conviction* this week.
- novelty and event intensity are near zero on average

## Top 20 Upside Pressure (UPS)

| Rank | Ticker | Sector | UPS_adj | Conviction | Drivers | Rationale | Signal state |
|---:|:---|:---|---:|:---|:---|:---|:---|
| 1 | GEN | Information Technology | 0.750 | Strong | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 2 | ROK | Industrials | 0.716 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 3 | AXON | Industrials | 0.694 | Moderate | Event intensity, Sentiment inflection | Ranked due to strong divergence: constructive news signals while recent price action remains weak. | Divergent |
| 4 | TSN | Consumer Staples | 0.676 | Moderate | Event intensity, Sentiment inflection | Ranked primarily due to recent price confirmation rather than new information. | Early |
| 5 | TMUS | Communication Services | 0.643 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 6 | PTC | Information Technology | 0.641 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 7 | CPAY | Financials | 0.633 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 8 | DVN | Energy | 0.633 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 9 | EPAM | Information Technology | 0.625 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 10 | LNT | Utilities | 0.611 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 11 | ED | Utilities | 0.604 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 12 | BEN | Financials | 0.604 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Divergent |
| 13 | VTRS | Health Care | 0.594 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 14 | FRT | Real Estate | 0.590 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 15 | DASH | Consumer Discretionary | 0.584 | Moderate | Event intensity, Sentiment inflection | Ranked due to strong divergence: constructive news signals while recent price action remains weak. | Divergent |
| 16 | HPE | Information Technology | 0.583 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Divergent |
| 17 | CAH | Health Care | 0.579 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 18 | NEM | Materials | 0.577 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 19 | AMP | Financials | 0.575 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 20 | EL | Consumer Staples | 0.572 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |

## Stock cards (Top UPS)

### GEN — Information Technology
- **UPS_adj:** 0.750 | **Conviction:** Strong | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.78
- Market context: AR5 4.77% · VS 0.65 · VR_pct 0.18
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Avast Brings AI-powered Scam Defense to Mobile** — The introduction of new mobile security features indicates growth potential for Avast within the mobile market.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### ROK — Industrials
- **UPS_adj:** 0.716 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.55
- Market context: AR5 1.67% · VS 0.42 · VR_pct 0.41
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **ROCKWELL AUTOMATION TO ADVANCE INDUSTRIAL INTELLIGENCE THROUGH EDGE-BASED GENERATIVE AI WITH NVIDIA NEMOTRON** — The announcement signifies a significant advancement in Rockwell's technological capabilities and market position.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### AXON — Industrials
- **UPS_adj:** 0.694 | **Conviction:** Moderate | **Signal state:** Divergent
- Ranking rationale: Ranked due to strong divergence: constructive news signals while recent price action remains weak.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.49
- Market context: AR5 -5.34% · VS 0.50 · VR_pct 0.90
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **AXON's Connected Devices Growth Picks Up: More Upside to Come?** — Surge in Connected Devices revenue suggests significant market opportunity.

**Key risks**
- Recent sharp move; risk of mean reversion
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### TSN — Consumer Staples
- **UPS_adj:** 0.676 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked primarily due to recent price confirmation rather than new information.
- Components: IFS 0.35 · EVS 1.46 · MCS_up 0.65
- Market context: AR5 4.81% · VS 0.53 · VR_pct 0.18
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **TSN Q3 Deep Dive: Chicken Momentum Offsets Beef Headwinds as Tyson Navigates Tight Protein Markets** — The earnings report highlights resilience in challenging market conditions.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### TMUS — Communication Services
- **UPS_adj:** 0.643 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.34
- Market context: AR5 6.49% · VS 0.07 · VR_pct 0.31
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Deutsche Telekom AG (DTEGF) Q3 2025 Earnings Call Highlights: Strong Growth in Earnings and ...** — The earnings call highlights significant growth and strategic advancements, suggesting a positive outlook.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### PTC — Information Technology
- **UPS_adj:** 0.641 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.34
- Market context: AR5 0.11% · VS 0.21 · VR_pct 0.42
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **PTC Ends Year With Strong Revenue Growth And Renewed Focus On Divestitures (Upgrade)** — The upgrade to Buy reflects confidence in PTC's growth and strategic direction.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### CPAY — Financials
- **UPS_adj:** 0.633 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.44
- Market context: AR5 1.59% · VS 0.34 · VR_pct 0.72
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **What Makes Corpay (CPAY) a New Buy Stock** — The upgrade to Zacks Rank #2 suggests increased analyst confidence in Corpay's performance.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### DVN — Energy
- **UPS_adj:** 0.633 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.44
- Market context: AR5 7.82% · VS 0.20 · VR_pct 0.72
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Devon Energy (DVN): Exploring Valuation After Earnings Beat and Major Buyback Completion** — The earnings beat and buyback completion suggest positive future performance.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### EPAM — Information Technology
- **UPS_adj:** 0.625 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.51 · EVS 0.78 · MCS_up 0.68
- Market context: AR5 7.17% · VS 0.44 · VR_pct 0.83
- Event tags: `OTHER_LOW_SIGNAL`

**What changed this week**
- **EPAM Wins the 2025 Microsoft Innovate with Azure AI Platform Partner of the Year Award** — The award recognition enhances EPAM's reputation and potential for future business opportunities.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### LNT — Utilities
- **UPS_adj:** 0.611 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.38
- Market context: AR5 0.77% · VS 0.28 · VR_pct 0.01
- Event tags: `OPERATIONS_SUPPLY`

**What changed this week**
- **Meta Begins Work On $1 Billion AI Data Center** — The investment in a new facility indicates growth and innovation in Meta's operations.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Evidence the operational issue is broader or longer-lived than expected

### ED — Utilities
- **UPS_adj:** 0.604 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.23
- Market context: AR5 3.83% · VS 0.00 · VR_pct 0.06
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **How Investors May Respond To Consolidated Edison (ED) Raising Guidance and Launching Major NY Infrastructure Plan** — Raising guidance and launching a major infrastructure plan signals confidence in future performance.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### BEN — Financials
- **UPS_adj:** 0.604 | **Conviction:** Moderate | **Signal state:** Divergent
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.23
- Market context: AR5 -4.35% · VS 0.19 · VR_pct 0.50
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Franklin Resources (BEN) Q4 Earnings and Revenues Beat Estimates** — The earnings and revenue surprises suggest potential for future growth.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### VTRS — Health Care
- **UPS_adj:** 0.594 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.33
- Market context: AR5 7.75% · VS 0.07 · VR_pct 0.71
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **How Recent Developments Are Rewriting the Story for Viatris** — Analysts adjusting the Fair Value Estimate reflects growing confidence in Viatris's future performance.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### FRT — Real Estate
- **UPS_adj:** 0.590 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.32
- Market context: AR5 1.58% · VS 0.20 · VR_pct 0.11
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **SPG Launches Simon+ Loyalty Program for Shoppers to Get Rewards** — Introducing a loyalty program is likely to attract more customers and increase revenue.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### DASH — Consumer Discretionary
- **UPS_adj:** 0.584 | **Conviction:** Moderate | **Signal state:** Divergent
- Ranking rationale: Ranked due to strong divergence: constructive news signals while recent price action remains weak.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.60
- Market context: AR5 -0.89% · VS 0.57 · VR_pct 0.91
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Sally Beauty Surpasses Q4 Estimates** — The company's exceeded estimates and strategic focus suggest a positive outlook for growth.

**Key risks**
- High volatility regime (position-level risk elevated)
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### HPE — Information Technology
- **UPS_adj:** 0.583 | **Conviction:** Moderate | **Signal state:** Divergent
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.17
- Market context: AR5 -2.23% · VS 0.07 · VR_pct 0.80
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Next-generation HPE Cray Supercomputing portfolio introduces industry-leading compute density to boost AI productivity** — The launch of new supercomputing products is expected to significantly boost HPE's market presence and revenue potentia…

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### CAH — Health Care
- **UPS_adj:** 0.579 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.29
- Market context: AR5 3.82% · VS 0.11 · VR_pct 0.83
- Event tags: `MANAGEMENT_GOVERNANCE`

**What changed this week**
- **OnPoint Surgical, Inc. Appoints Jeremy Laynor as Chief Commercial Officer to Accelerate Global Growth** — The leadership change aims to accelerate global growth for OnPoint Surgical.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### NEM — Materials
- **UPS_adj:** 0.577 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.15
- Market context: AR5 8.46% · VS -0.19 · VR_pct 0.90
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Should AU Stock Be Part of Your Portfolio Post Q3 Results?** — Q3 results and strategic moves suggest a favorable market position for AU.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### AMP — Financials
- **UPS_adj:** 0.575 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.51 · EVS 1.46 · MCS_up 0.15
- Market context: AR5 0.16% · VS -0.01 · VR_pct 0.31
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Ameriprise Financial (AMP): A Fresh Look at Valuation Following Strong Q3 Earnings Surge** — Impressive Q3 results suggest favorable future performance and investor confidence.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### EL — Consumer Staples
- **UPS_adj:** 0.572 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.41 · EVS 1.46 · MCS_up 0.27
- Market context: AR5 2.19% · VS 0.12 · VR_pct 0.85
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **The Estée Lauder Companies Makes Strategic Minority Investment in Mexican Luxury Fragrance Brand XINÚ** — The investment in XINÚ represents a significant strategic move into the Latin American market.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

## Bottom 20 Downside Pressure (DPS) snapshot

| Rank | Ticker | Sector | DPS_adj | Primary concern |
|---:|:---|:---|---:|:---|
| 1 | TTWO | Communication Services | 0.462 | Event intensity negative |
| 2 | PH | Industrials | 0.383 | Event intensity negative |
| 3 | ZTS | Health Care | 0.381 | Event intensity negative |
| 4 | CSCO | Information Technology | 0.380 | Event intensity negative |
| 5 | META | Communication Services | 0.375 | Event intensity negative |
| 6 | DTE | Utilities | 0.373 | Event intensity negative |
| 7 | BALL | Materials | 0.371 | Event intensity negative |
| 8 | PNW | Utilities | 0.371 | Event intensity negative |
| 9 | STE | Health Care | 0.369 | Event intensity negative |
| 10 | TDY | Information Technology | 0.367 | Event intensity negative |
| 11 | KKR | Financials | 0.363 | Event intensity negative |
| 12 | DUK | Utilities | 0.357 | Event intensity negative |
| 13 | CEG | Utilities | 0.352 | Event intensity negative |
| 14 | LYV | Communication Services | 0.345 | Event intensity negative |
| 15 | ZBRA | Information Technology | 0.344 | Event intensity negative |
| 16 | BDX | Health Care | 0.340 | Event intensity negative |
| 17 | AKAM | Information Technology | 0.339 | Event intensity negative |
| 18 | BX | Financials | 0.339 | Event intensity negative |
| 19 | ABNB | Consumer Discretionary | 0.337 | Event intensity negative |
| 20 | ESS | Real Estate | 0.336 | Event intensity negative |

## What this is / isn't

**What this report is**
- A systematic scan of weekly news-driven market pressure (UPS/DPS)
- A way to surface information flow shifts you may not have time to track manually
- A starting point for your own due diligence and risk decisions

**What this report is not**
- Investment advice
- A prediction of price movements
- A substitute for portfolio-level risk management

## Build Stamp

For full traceability and reproducibility:

- **Git SHA:** `e1420854a3e9...` (full: `e1420854a3e99ec06100d727cbbabe14d91b0f13`)
- **GitHub Run:** `21343113978` (attempt 1)
- **features_scores.py SHA256:** `cc6abaaf8c2a089f...`
- **Python:** 3.11.14
- **Dependencies:** pandas 3.0.0, numpy 2.4.1
