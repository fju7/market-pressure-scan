# Weekly Market Pressure Report
**Week Ending:** 2025-11-27

This report ranks S&P 500 names by **Upside Pressure (UPS)** using weekly news novelty, event intensity, sentiment shift, and market confirmation. Use it as a **screen and context tool**, not as a standalone trading instruction.

## Signal quality snapshot
- Avg novelty (z): 0.00
- Avg event intensity (z): -0.00
- Avg price-action news rate: 0.51
- PRICE_ACTION_RECAP (% of clusters): 39%
- Sector mix (Top 20): Health Care: 8, Consumer Discretionary: 4, Information Technology: 2, Industrials: 2, Financials: 1, Communication Services: 1, Materials: 1, Consumer Staples: 1

## ⚠️ Low-information week
The system is seeing mostly market wrap / price-move recap content rather than company-specific events. Treat UPS/DPS rankings as *low conviction* this week.
- novelty and event intensity are near zero on average

## Top 20 Upside Pressure (UPS)

| Rank | Ticker | Sector | UPS_adj | Conviction | Drivers | Rationale | Signal state |
|---:|:---|:---|---:|:---|:---|:---|:---|
| 1 | RVTY | Health Care | 0.717 | Moderate | Event intensity, Sentiment inflection | Ranked primarily due to recent price confirmation rather than new information. | Early |
| 2 | ADI | Information Technology | 0.665 | Moderate | Event intensity, Sentiment inflection | Ranked primarily due to recent price confirmation rather than new information. | Early |
| 3 | ZTS | Health Care | 0.596 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 4 | REGN | Health Care | 0.591 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 5 | DVA | Health Care | 0.586 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 6 | FIX | Industrials | 0.572 | Moderate | Event intensity, Sentiment inflection | Ranked primarily due to recent price confirmation rather than new information. | Early |
| 7 | XYZ | Financials | 0.562 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 8 | OMC | Communication Services | 0.532 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 9 | TSCO | Consumer Discretionary | 0.527 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 10 | ZBH | Health Care | 0.486 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 11 | BMY | Health Care | 0.472 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 12 | VRSN | Information Technology | 0.470 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 13 | FTV | Industrials | 0.469 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 14 | ULTA | Consumer Discretionary | 0.464 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 15 | APTV | Consumer Discretionary | 0.456 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 16 | BALL | Materials | 0.453 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 17 | VRTX | Health Care | 0.443 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 18 | DG | Consumer Staples | 0.440 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 19 | HLT | Consumer Discretionary | 0.435 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 20 | BAX | Health Care | 0.435 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |

## Stock cards (Top UPS)

### RVTY — Health Care
- **UPS_adj:** 0.717 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked primarily due to recent price confirmation rather than new information.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 1.00
- Market context: AR5 10.89% · VS 0.94 · VR_pct 0.75
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **Revvity (RVTY): Evaluating Valuation Following Latest Financial Results and Share Price Rebound** — The analysis of Revvity's financial results and share price rebound suggests a positive outlook.

**Key risks**
- Recent sharp move; risk of mean reversion
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### ADI — Information Technology
- **UPS_adj:** 0.665 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked primarily due to recent price confirmation rather than new information.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.73
- Market context: AR5 8.51% · VS 0.56 · VR_pct 0.63
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Analog Devices (ADI) Q4 Earnings and Revenues Surpass Estimates** — Surpassing earnings and revenue estimates suggests positive future outlook for the company.

**Key risks**
- Recent sharp move; risk of mean reversion
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### ZTS — Health Care
- **UPS_adj:** 0.596 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.53
- Market context: AR5 6.50% · VS 0.38 · VR_pct 0.76
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Zoetis Receives European Commission Marketing Authorization for Lenivia® (izenivetmab) to Reduce Pain Associated with O…** — The authorization signifies a strategic advancement in Zoetis' offerings in the veterinary market.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### REGN — Health Care
- **UPS_adj:** 0.591 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.52
- Market context: AR5 9.08% · VS 0.28 · VR_pct 0.83
- Event tags: `REGULATORY_LEGAL`

**What changed this week**
- **Regeneron, Sanofi Get EU Approval For Dupixent in Skin Disease CSU -- Update** — The approval signifies a significant regulatory milestone for Regeneron and Sanofi.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- New filings, adverse rulings, or regulatory actions that escalate scope

### DVA — Health Care
- **UPS_adj:** 0.586 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.20 · EVS 1.53 · MCS_up 0.54
- Market context: AR5 1.69% · VS 0.59 · VR_pct 0.52
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **Fresenius Medical Care: 'Buy' Again Following A Peak In May** — Analyst upgrade suggests confidence in the company's growth and profitability.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### FIX — Industrials
- **UPS_adj:** 0.572 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked primarily due to recent price confirmation rather than new information.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.75
- Market context: AR5 1.77% · VS 0.82 · VR_pct 0.96
- Event tags: `OPERATIONS_SUPPLY`

**What changed this week**
- **Jacobs & Arcadis JV Wins New Rail Project From TMR in Australia** — Winning the rail project signifies operational success and strategic growth for Jacobs.

**Key risks**
- High volatility regime (position-level risk elevated)
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Evidence the operational issue is broader or longer-lived than expected

### XYZ — Financials
- **UPS_adj:** 0.562 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.44
- Market context: AR5 2.33% · VS 0.41 · VR_pct 0.88
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Galileo Strengthens SoFi's Fintech Integration and Growth Path** — The partnership is expected to drive innovation and improve market positioning.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### OMC — Communication Services
- **UPS_adj:** 0.532 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.35
- Market context: AR5 -3.26% · VS 0.51 · VR_pct 0.58
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Omnicom, Interpublic Group receive unconditional clearance from EC** — The approval is crucial for completing the acquisition, indicating strong regulatory support.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### TSCO — Consumer Discretionary
- **UPS_adj:** 0.527 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.33
- Market context: AR5 1.42% · VS 0.32 · VR_pct 0.28
- Event tags: `OPERATIONS_SUPPLY`

**What changed this week**
- **Can Tractor Supply's Rural Lifestyle Demand Offset Cost Pressures?** — Rural demand and cost control measures suggest operational strength and resilience.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Evidence the operational issue is broader or longer-lived than expected

### ZBH — Health Care
- **UPS_adj:** 0.486 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.34
- Market context: AR5 6.49% · VS 0.19 · VR_pct 0.82
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **From Hospitals to ASCs: Will Refurbished Xi Systems Broaden ISRG's Reach?** — Leveraging refurbished systems indicates strategic growth in new market segments.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### BMY — Health Care
- **UPS_adj:** 0.472 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.18
- Market context: AR5 5.00% · VS -0.00 · VR_pct 0.60
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **BMY Wins EC Nod for Label Expansion of CAR T Cell Therapy Breyanzi (Revised)** — The label expansion significantly broadens the therapy's applicability in the European market.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### VRSN — Information Technology
- **UPS_adj:** 0.470 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.30
- Market context: AR5 0.24% · VS 0.36 · VR_pct 0.36
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **VeriSign (VRSN) Q3 2025 Earnings Call Transcript** — The earnings call highlights growth and shareholder returns, signaling strong company performance.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### FTV — Industrials
- **UPS_adj:** 0.469 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.17
- Market context: AR5 3.02% · VS 0.06 · VR_pct 0.21
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Woodward's Q4 Earnings Surge 48% Y/Y, Revenues Beat, Shares Rise** — Q4 earnings and positive outlook suggest strong future performance.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### ULTA — Consumer Discretionary
- **UPS_adj:** 0.464 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.28
- Market context: AR5 5.02% · VS 0.17 · VR_pct 0.41
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Ulta Beauty (ULTA) Expected to Beat Earnings Estimates: What to Know Ahead of Q3 Release** — The anticipation of an earnings beat suggests positive market sentiment and operational strength.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### APTV — Consumer Discretionary
- **UPS_adj:** 0.456 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.26
- Market context: AR5 3.62% · VS 0.19 · VR_pct 0.58
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Aptiv (APTV) Q3 2025 Earnings Call Transcript** — The earnings call highlights significant growth in operating income, reflecting positive business trends.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### BALL — Materials
- **UPS_adj:** 0.453 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.25
- Market context: AR5 1.78% · VS 0.24 · VR_pct 0.37
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **/C O R R E C T I O N -- Ball Corporation/** — The completion of new credit facilities indicates a strengthening of Ball Corporation's capital structure.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### VRTX — Health Care
- **UPS_adj:** 0.443 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.23 · EVS 1.53 · MCS_up 0.10
- Market context: AR5 0.07% · VS 0.07 · VR_pct 0.22
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Vertex (VRTX) Q3 2025 Earnings Call Transcript** — The earnings call highlights strong performance and future growth plans, signaling positive outlook.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### DG — Consumer Staples
- **UPS_adj:** 0.440 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.21
- Market context: AR5 6.59% · VS 0.02 · VR_pct 0.63
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Dollar General (DG) Earnings Expected to Grow: Should You Buy?** — The article discusses positive earnings expectations for Dollar General.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### HLT — Consumer Discretionary
- **UPS_adj:** 0.435 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.20
- Market context: AR5 4.46% · VS 0.08 · VR_pct 0.37
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Hilton (HLT): Evaluating Valuation After Launching New Loyalty Tiers and Luxury Expansion** — The launch of new loyalty tiers and benefits indicates a strategic move to strengthen market position.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### BAX — Health Care
- **UPS_adj:** 0.435 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.13 · EVS 1.53 · MCS_up 0.20
- Market context: AR5 4.38% · VS 0.09 · VR_pct 0.87
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Baxter: Temporary Headwinds Mask The Earnings Power Of Its Core Business** — The resolution of company-specific issues suggests improved earnings potential.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

## Bottom 20 Downside Pressure (DPS) snapshot

| Rank | Ticker | Sector | DPS_adj | Primary concern |
|---:|:---|:---|---:|:---|
| 1 | PANW | Information Technology | 0.631 | Event intensity negative |
| 2 | WDAY | Information Technology | 0.611 | Event intensity negative |
| 3 | PODD | Health Care | 0.608 | Event intensity negative |
| 4 | AKAM | Information Technology | 0.587 | Event intensity negative |
| 5 | DE | Industrials | 0.565 | Event intensity negative |
| 6 | TAP | Consumer Staples | 0.562 | Event intensity negative |
| 7 | VICI | Real Estate | 0.560 | Event intensity negative |
| 8 | ATO | Utilities | 0.558 | Event intensity negative |
| 9 | IRM | Real Estate | 0.532 | Event intensity negative |
| 10 | NVDA | Information Technology | 0.529 | Event intensity negative |
| 11 | FFIV | Information Technology | 0.527 | Event intensity negative |
| 12 | INTU | Information Technology | 0.523 | Event intensity negative |
| 13 | ADSK | Information Technology | 0.509 | Event intensity negative |
| 14 | GE | Industrials | 0.504 | Event intensity negative |
| 15 | NTAP | Information Technology | 0.501 | Event intensity negative |
| 16 | VLTO | Industrials | 0.491 | Event intensity negative |
| 17 | ABT | Health Care | 0.484 | Event intensity negative |
| 18 | J | Industrials | 0.482 | Market downside confirmation |
| 19 | GOOGL | Communication Services | 0.474 | Event intensity negative |
| 20 | CVX | Energy | 0.473 | Event intensity negative |

## What this is / isn't

**What this report is**
- A systematic scan of weekly news-driven market pressure (UPS/DPS)
- A way to surface information flow shifts you may not have time to track manually
- A starting point for your own due diligence and risk decisions

**What this report is not**
- Investment advice
- A prediction of price movements
- A substitute for portfolio-level risk management

## Build Stamp

For full traceability and reproducibility:

- **Git SHA:** `facf01ed1664...` (full: `facf01ed1664f1a79026492471bf49506badbb23`)
- **GitHub Run:** `21336537756` (attempt 1)
- **features_scores.py SHA256:** `94ef473c17741257...`
- **Python:** 3.11.14
- **Dependencies:** pandas 3.0.0, numpy 2.4.1
