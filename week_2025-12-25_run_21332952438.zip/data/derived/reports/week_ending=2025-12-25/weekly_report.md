# Weekly Market Pressure Report
**Week Ending:** 2025-12-25

This report ranks S&P 500 names by **Upside Pressure (UPS)** using weekly news novelty, event intensity, sentiment shift, and market confirmation. Use it as a **screen and context tool**, not as a standalone trading instruction.

## Signal quality snapshot
- Avg novelty (z): 0.00
- Avg event intensity (z): -0.00
- Avg price-action news rate: 0.52
- PRICE_ACTION_RECAP (% of clusters): 35%
- Sector mix (Top 20): Health Care: 6, Industrials: 3, Information Technology: 2, Communication Services: 2, Financials: 2, Consumer Discretionary: 1, Consumer Staples: 1, Utilities: 1, Real Estate: 1, Energy: 1

## ⚠️ Low-information week
The system is seeing mostly market wrap / price-move recap content rather than company-specific events. Treat UPS/DPS rankings as *low conviction* this week.
- novelty and event intensity are near zero on average

## Top 20 Upside Pressure (UPS)

| Rank | Ticker | Sector | UPS_adj | Conviction | Drivers | Rationale | Signal state |
|---:|:---|:---|---:|:---|:---|:---|:---|
| 1 | BIIB | Health Care | 0.619 | Moderate | Event intensity, Sentiment inflection | Ranked primarily due to recent price confirmation rather than new information. | Early |
| 2 | DRI | Consumer Discretionary | 0.613 | Moderate | Event intensity, Sentiment inflection | Ranked primarily due to recent price confirmation rather than new information. | Early |
| 3 | PANW | Information Technology | 0.556 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 4 | PAYX | Industrials | 0.549 | Moderate | Event intensity, Sentiment inflection | Ranked due to strong divergence: constructive news signals while recent price action remains weak. | Early |
| 5 | NWS | Communication Services | 0.544 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 6 | C | Financials | 0.543 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 7 | SOLV | Health Care | 0.542 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 8 | VRTX | Health Care | 0.538 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 9 | AMGN | Health Care | 0.536 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 10 | HCA | Health Care | 0.529 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 11 | FTNT | Information Technology | 0.516 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 12 | NWSA | Communication Services | 0.509 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 13 | WMT | Consumer Staples | 0.507 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 14 | VLTO | Industrials | 0.504 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 15 | ETR | Utilities | 0.498 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 16 | DLR | Real Estate | 0.496 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 17 | ACGL | Financials | 0.492 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 18 | AXON | Industrials | 0.484 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 19 | EOG | Energy | 0.478 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 20 | REGN | Health Care | 0.476 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |

## Stock cards (Top UPS)

### BIIB — Health Care
- **UPS_adj:** 0.619 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked primarily due to recent price confirmation rather than new information.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.71
- Market context: AR5 -0.36% · VS 0.72 · VR_pct 0.72
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **Eli Lilly: Mr. Market Finally Woke Up, But I'm Not Out Yet (Rating Downgrade)** — The rating downgrade reflects market adjustments but maintains a positive outlook on Eli Lilly's performance.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### DRI — Consumer Discretionary
- **UPS_adj:** 0.613 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked primarily due to recent price confirmation rather than new information.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.69
- Market context: AR5 -2.62% · VS 0.67 · VR_pct 0.33
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **The Top 5 Analyst Questions From Darden’s Q4 Earnings Call** — Darden exceeded revenue expectations, signaling strong future performance.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### PANW — Information Technology
- **UPS_adj:** 0.556 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.27 · EVS 1.47 · MCS_up 0.40
- Market context: AR5 -0.76% · VS 0.26 · VR_pct 0.60
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Palo Alto Networks, Google Cloud to Expand Partnership in Multibillion-Dollar Deal** — The multibillion-dollar deal signifies a significant strategic move for both companies.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### PAYX — Industrials
- **UPS_adj:** 0.549 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to strong divergence: constructive news signals while recent price action remains weak.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.51
- Market context: AR5 -4.64% · VS 0.42 · VR_pct 0.27
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **PAYX Q4 Deep Dive: AI Investments and Paycor Integration Shape Outlook Amid Margin Pressures** — The strong Q4 results and positive outlook reflect effective management and strategic investments.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### NWS — Communication Services
- **UPS_adj:** 0.544 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.50
- Market context: AR5 -1.44% · VS 0.43 · VR_pct 0.55
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **Is News Corp’s US$1 Billion Buyback Shifting The Capital Return Story For NWSA?** — The substantial buyback is expected to positively impact the company's capital return narrative.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### C — Financials
- **UPS_adj:** 0.543 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.49
- Market context: AR5 6.24% · VS 0.49 · VR_pct 0.41
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Citigroup (C): Valuation Check After Regulatory Relief, Banamex Stake Sale Progress and Turnaround Optimism** — The sale of Banamex and regulatory changes enhance strategic positioning.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### SOLV — Health Care
- **UPS_adj:** 0.542 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.27 · EVS 1.47 · MCS_up 0.36
- Market context: AR5 -2.53% · VS 0.19 · VR_pct 0.55
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **SOLV Acquires Acera Surgical to Expand Advanced Wound Care Portfolio** — The acquisition of Acera Surgical is a strategic move to strengthen Solventum's portfolio.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### VRTX — Health Care
- **UPS_adj:** 0.538 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.27 · EVS 1.47 · MCS_up 0.35
- Market context: AR5 0.17% · VS 0.20 · VR_pct 0.46
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Agios Pharma Stock: A Buy After FDA Approves Aqvesme** — FDA approval is a significant strategic milestone for Agios Pharma.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### AMGN — Health Care
- **UPS_adj:** 0.536 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.47
- Market context: AR5 -0.39% · VS 0.41 · VR_pct 0.60
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Amgen Strikes Drug Pricing Deal With Trump: What Investors Should Know** — The deal indicates strategic alignment with government policies, potentially benefiting Amgen's market position.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### HCA — Health Care
- **UPS_adj:** 0.529 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.27 · EVS 1.47 · MCS_up 0.33
- Market context: AR5 -2.36% · VS 0.15 · VR_pct 0.44
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **What HCA Healthcare (HCA)'s Upbeat 2025 Guidance and Buybacks Mean For Shareholders** — The raised revenue and earnings guidance reflects strong future performance expectations.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### FTNT — Information Technology
- **UPS_adj:** 0.516 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.42
- Market context: AR5 -0.55% · VS 0.34 · VR_pct 0.56
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Can AI Data Center Partnership With Fortinet Lift Arista's Shares?** — The collaboration signifies a strategic move to strengthen market position in AI data solutions.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### NWSA — Communication Services
- **UPS_adj:** 0.509 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.40
- Market context: AR5 -1.21% · VS 0.31 · VR_pct 0.54
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **Is News Corp’s US$1 Billion Buyback Shifting The Capital Return Story For NWSA?** — The substantial buyback signals a strategic shift towards improving capital returns and shareholder value.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### WMT — Consumer Staples
- **UPS_adj:** 0.507 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.39
- Market context: AR5 -6.32% · VS 0.25 · VR_pct 0.39
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Walmart muscles its way into New York City as ecommerce sales leap** — Walmart's entry into NYC highlights its strategic focus on ecommerce growth.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### VLTO — Industrials
- **UPS_adj:** 0.504 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.38
- Market context: AR5 -0.58% · VS 0.29 · VR_pct 0.20
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **Veralto (VLTO) Dividend Hike: Evaluating the Stock’s Valuation After an 18% Payout Increase** — The dividend increase reflects confidence in the company's financial stability and growth prospects.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### ETR — Utilities
- **UPS_adj:** 0.498 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.27 · EVS 1.47 · MCS_up 0.24
- Market context: AR5 -1.90% · VS 0.04 · VR_pct 0.08
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **Entergy: Favorable Demand And Regulatory Trends (Upgrade)** — The upgrade reflects confidence in Entergy's growth and income potential.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### DLR — Real Estate
- **UPS_adj:** 0.496 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.36
- Market context: AR5 1.76% · VS 0.28 · VR_pct 0.42
- Event tags: `OPERATIONS_SUPPLY`

**What changed this week**
- **Blackstone's AirTrunk to Build $3.33B Melbourne Data Center** — The construction of a major data center reflects strategic expansion in a key market.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Evidence the operational issue is broader or longer-lived than expected

### ACGL — Financials
- **UPS_adj:** 0.492 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.35
- Market context: AR5 -2.29% · VS 0.24 · VR_pct 0.12
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **Does AM Best’s Upgraded Credit View Reshape the Bull Case for Arch Capital Group (ACGL)?** — The upgrade by AM Best indicates improved creditworthiness and potential for future growth.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### AXON — Industrials
- **UPS_adj:** 0.484 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.17 · EVS 1.47 · MCS_up 0.32
- Market context: AR5 4.66% · VS 0.26 · VR_pct 0.88
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Is Axon (AXON) Quietly Recasting Its Risk Profile With Debt Moves And AI-Driven Contracts?** — The strategic moves in debt and contracts suggest a significant shift in Axon's operational focus.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### EOG — Energy
- **UPS_adj:** 0.478 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.24 · EVS 1.47 · MCS_up 0.22
- Market context: AR5 -3.65% · VS 0.02 · VR_pct 0.25
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **EOG Resources: Buy The Dip For A Reputable Producer** — The acquisition of Encino is a strategic move to expand EOG's operational footprint.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### REGN — Health Care
- **UPS_adj:** 0.476 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.27 · EVS 1.47 · MCS_up 0.17
- Market context: AR5 1.70% · VS -0.01 · VR_pct 0.84
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Press Release: Sanofi and Regeneron’s Dupixent approved in Japan for children aged 6 to 11 years with bronchial asthma** — The approval of Dupixent in Japan represents a significant advancement in treatment options for pediatric asthma.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

## Bottom 20 Downside Pressure (DPS) snapshot

| Rank | Ticker | Sector | DPS_adj | Primary concern |
|---:|:---|:---|---:|:---|
| 1 | CBOE | Financials | 0.547 | Event intensity negative |
| 2 | D | Utilities | 0.506 | Event intensity negative |
| 3 | FIX | Industrials | 0.504 | Event intensity negative |
| 4 | HII | Industrials | 0.495 | Event intensity negative |
| 5 | NDAQ | Financials | 0.490 | Event intensity negative |
| 6 | AVGO | Information Technology | 0.470 | Event intensity negative |
| 7 | MO | Consumer Staples | 0.466 | Event intensity negative |
| 8 | NOW | Information Technology | 0.460 | Event intensity negative |
| 9 | MRK | Health Care | 0.455 | Event intensity negative |
| 10 | CSCO | Information Technology | 0.450 | Event intensity negative |
| 11 | CRH | Materials | 0.449 | Market downside confirmation |
| 12 | WBD | Communication Services | 0.445 | Event intensity negative |
| 13 | RSG | Industrials | 0.443 | Event intensity negative |
| 14 | MSI | Information Technology | 0.441 | Event intensity negative |
| 15 | NVR | Consumer Discretionary | 0.439 | Event intensity negative |
| 16 | TDG | Industrials | 0.427 | Event intensity negative |
| 17 | AFL | Financials | 0.426 | Event intensity negative |
| 18 | ORLY | Consumer Discretionary | 0.424 | Event intensity negative |
| 19 | CTAS | Industrials | 0.421 | Event intensity negative |
| 20 | NTRS | Financials | 0.418 | Event intensity negative |

## What this is / isn't

**What this report is**
- A systematic scan of weekly news-driven market pressure (UPS/DPS)
- A way to surface information flow shifts you may not have time to track manually
- A starting point for your own due diligence and risk decisions

**What this report is not**
- Investment advice
- A prediction of price movements
- A substitute for portfolio-level risk management

## Build Stamp

For full traceability and reproducibility:

- **Git SHA:** `facf01ed1664...` (full: `facf01ed1664f1a79026492471bf49506badbb23`)
- **GitHub Run:** `21332952438` (attempt 1)
- **features_scores.py SHA256:** `94ef473c17741257...`
- **Python:** 3.11.14
- **Dependencies:** pandas 3.0.0, numpy 2.4.1
