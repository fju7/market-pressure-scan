# Weekly Market Pressure Report
**Week Ending:** 2025-12-18

This report ranks S&P 500 names by **Upside Pressure (UPS)** using weekly news novelty, event intensity, sentiment shift, and market confirmation. Use it as a **screen and context tool**, not as a standalone trading instruction.

## Signal quality snapshot
- Avg novelty (z): 0.00
- Avg event intensity (z): 0.00
- Avg price-action news rate: 0.57
- PRICE_ACTION_RECAP (% of clusters): 45%
- Sector mix (Top 20): Financials: 8, Industrials: 6, Information Technology: 4, Consumer Discretionary: 1, Utilities: 1

## ⚠️ Low-information week
The system is seeing mostly market wrap / price-move recap content rather than company-specific events. Treat UPS/DPS rankings as *low conviction* this week.
- novelty and event intensity are near zero on average

## Top 20 Upside Pressure (UPS)

| Rank | Ticker | Sector | UPS_adj | Conviction | Drivers | Rationale | Signal state |
|---:|:---|:---|---:|:---|:---|:---|:---|
| 1 | DRI | Consumer Discretionary | 0.820 | Strong | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 2 | JBL | Information Technology | 0.755 | Strong | Event intensity, Sentiment inflection | Ranked due to strong divergence: constructive news signals while recent price action remains weak. | Divergent |
| 3 | DTE | Utilities | 0.724 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 4 | CTSH | Information Technology | 0.722 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 5 | VLTO | Industrials | 0.720 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 6 | AFL | Financials | 0.719 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 7 | GE | Industrials | 0.719 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 8 | AIG | Financials | 0.717 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 9 | MSI | Information Technology | 0.710 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 10 | LUV | Industrials | 0.697 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 11 | TXT | Industrials | 0.681 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 12 | ERIE | Financials | 0.673 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 13 | TRV | Financials | 0.672 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 14 | CTAS | Industrials | 0.659 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 15 | MET | Financials | 0.656 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 16 | ACGL | Financials | 0.651 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 17 | EFX | Industrials | 0.636 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 18 | SCHW | Financials | 0.628 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 19 | PTC | Information Technology | 0.627 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 20 | CPAY | Financials | 0.616 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Divergent |

## Stock cards (Top UPS)

### DRI — Consumer Discretionary
- **UPS_adj:** 0.820 | **Conviction:** Strong | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.86
- Market context: AR5 7.07% · VS 0.66 · VR_pct 0.33
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Darden Restaurants Inc (DRI) Q2 2026 Earnings Call Highlights: Strong Sales Growth Amid ...** — The earnings call highlights strong sales growth, suggesting a positive outlook for the company.

**Key risks**
- Recent sharp move; risk of mean reversion
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### JBL — Information Technology
- **UPS_adj:** 0.755 | **Conviction:** Strong | **Signal state:** Divergent
- Ranking rationale: Ranked due to strong divergence: constructive news signals while recent price action remains weak.
- Components: IFS 0.54 · EVS 1.62 · MCS_up 0.54
- Market context: AR5 -5.50% · VS 0.60 · VR_pct 0.86
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **JBL Q4 Deep Dive: Data Center and AI Demand Drive Broad-Based Growth** — JBL's Q4 results and optimistic guidance suggest strong future performance.

**Key risks**
- Recent sharp move; risk of mean reversion
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### DTE — Utilities
- **UPS_adj:** 0.724 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.58
- Market context: AR5 1.20% · VS 0.52 · VR_pct 0.02
- Event tags: `REGULATORY_LEGAL`

**What changed this week**
- **Oracle and OpenAI Win Michigan Approval to Power New Data Center** — Regulatory approval enhances DTE's operational capabilities and financial outlook.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- New filings, adverse rulings, or regulatory actions that escalate scope

### CTSH — Information Technology
- **UPS_adj:** 0.722 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.54 · EVS 1.62 · MCS_up 0.44
- Market context: AR5 1.78% · VS 0.32 · VR_pct 0.41
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Cognizant and Microsoft Expand Partnership to Advance AI Transformation and Frontier Firm Experiences** — The strategic partnership signifies a strong commitment to innovation and market leadership.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### VLTO — Industrials
- **UPS_adj:** 0.720 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.54 · EVS 1.62 · MCS_up 0.44
- Market context: AR5 3.92% · VS 0.25 · VR_pct 0.20
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **Veralto Announces Increase in Quarterly Dividend** — The dividend increase indicates confidence in future earnings and cash flow stability.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### AFL — Financials
- **UPS_adj:** 0.719 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.57
- Market context: AR5 3.33% · VS 0.45 · VR_pct 0.06
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Ethos and Aflac Partner to Bring Supplemental Health Product Suite to Independent Distribution** — The collaboration introduces new products to a broader market, indicating growth potential.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### GE — Industrials
- **UPS_adj:** 0.719 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.57
- Market context: AR5 6.45% · VS 0.37 · VR_pct 0.43
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Why GE Aerospace (GE) Stock Is Trading Up Today** — The milestone achievement in engine performance positively impacts market perception and demand for GE Aerospace produc…

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### AIG — Financials
- **UPS_adj:** 0.717 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.56
- Market context: AR5 5.88% · VS 0.38 · VR_pct 0.50
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **AIG to Form Special Purpose Vehicle through a Strategic Partnership with Amwins and Blackstone, and Launches Collaborat…** — The partnership with Amwins and Blackstone enhances AIG's market position and capabilities.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### MSI — Information Technology
- **UPS_adj:** 0.710 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.54
- Market context: AR5 3.39% · VS 0.42 · VR_pct 0.29
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Comtech Telecommunications: A Small-Cap Turnaround Ready To Launch** — The potential sale of $300–600M suggests significant strategic value.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### LUV — Industrials
- **UPS_adj:** 0.697 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.50
- Market context: AR5 1.84% · VS 0.42 · VR_pct 0.81
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Southwest Airlines Ties Up With Turkish Airlines for Global Connection** — The collaboration with Turkish Airlines signifies a strategic expansion in international travel offerings.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### TXT — Industrials
- **UPS_adj:** 0.681 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.46
- Market context: AR5 3.13% · VS 0.34 · VR_pct 0.23
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Textron (TXT) Valuation Check After Civil Air Patrol Expands Cessna Fleet with New Aircraft Order** — The Civil Air Patrol's order enhances Textron's market position and growth potential.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### ERIE — Financials
- **UPS_adj:** 0.673 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.44
- Market context: AR5 5.46% · VS 0.25 · VR_pct 0.63
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **Erie Indemnity (NASDAQ:ERIE) Will Pay A Larger Dividend Than Last Year At $1.46** — The larger dividend payment reflects improved profitability and a positive outlook for the company.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### TRV — Financials
- **UPS_adj:** 0.672 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.43
- Market context: AR5 5.65% · VS 0.24 · VR_pct 0.12
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **How Recent Developments Are Rewriting The Travelers Companies Investment Story** — The upgrade in estimated fair value reflects improved investor sentiment and fundamentals.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### CTAS — Industrials
- **UPS_adj:** 0.659 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.40
- Market context: AR5 2.41% · VS 0.29 · VR_pct 0.14
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Cintas (CTAS) Q2 Earnings and Revenues Beat Estimates** — The earnings beat suggests potential for continued growth and investor confidence.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### MET — Financials
- **UPS_adj:** 0.656 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.39
- Market context: AR5 1.20% · VS 0.31 · VR_pct 0.32
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **MetLife (MET) Valuation Review as New Petstablished Partnership Expands Its Pet Insurance Reach** — The new partnership significantly expands MetLife's offerings in a growing market.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### ACGL — Financials
- **UPS_adj:** 0.651 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.37
- Market context: AR5 4.85% · VS 0.20 · VR_pct 0.13
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **AM Best Upgrades Issuer Credit Rating for Arch Capital Group Ltd. and Its Subsidiaries** — The credit rating upgrade reflects a favorable assessment by AM Best.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### EFX — Industrials
- **UPS_adj:** 0.636 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.54 · EVS 1.62 · MCS_up 0.20
- Market context: AR5 1.31% · VS 0.07 · VR_pct 0.56
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Accenture Earnings Beat Estimates in Q1, Revenues Increase Y/Y** — The earnings beat and revenue increase suggest a favorable outlook for Accenture.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### SCHW — Financials
- **UPS_adj:** 0.628 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.31
- Market context: AR5 2.04% · VS 0.21 · VR_pct 0.14
- Event tags: `MANAGEMENT_GOVERNANCE`

**What changed this week**
- **Schwab CEO Rick Wurster Draws a ‘Bright Line’ Between Investing and Gambling** — The CEO's clear position enhances Schwab's brand integrity and governance.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### PTC — Information Technology
- **UPS_adj:** 0.627 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.43 · EVS 1.62 · MCS_up 0.31
- Market context: AR5 0.67% · VS 0.24 · VR_pct 0.45
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **PTC Showcases Intelligent Product Lifecycle Vision with Lamborghini at CES 2026** — The demonstration at CES 2026 signifies a strategic partnership that could enhance PTC's market position.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### CPAY — Financials
- **UPS_adj:** 0.616 | **Conviction:** Moderate | **Signal state:** Divergent
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.54 · EVS 1.62 · MCS_up 0.14
- Market context: AR5 -1.33% · VS 0.07 · VR_pct 0.72
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Accenture Earnings Beat Estimates in Q1, Revenues Increase Y/Y** — The earnings beat and revenue increase suggest a positive outlook for Accenture's future performance.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

## Bottom 20 Downside Pressure (DPS) snapshot

| Rank | Ticker | Sector | DPS_adj | Primary concern |
|---:|:---|:---|---:|:---|
| 1 | AVGO | Information Technology | 0.459 | Event intensity negative |
| 2 | CBOE | Financials | 0.441 | Event intensity negative |
| 3 | DLR | Real Estate | 0.421 | Event intensity negative |
| 4 | TDG | Industrials | 0.409 | Event intensity negative |
| 5 | PSA | Real Estate | 0.401 | Event intensity negative |
| 6 | MPC | Energy | 0.398 | Event intensity negative |
| 7 | NDSN | Industrials | 0.397 | Event intensity negative |
| 8 | ORCL | Information Technology | 0.387 | Event intensity negative |
| 9 | MOS | Materials | 0.373 | Event intensity negative |
| 10 | NOW | Information Technology | 0.370 | Market downside confirmation |
| 11 | TPL | Energy | 0.369 | Event intensity negative |
| 12 | JCI | Industrials | 0.363 | Event intensity negative |
| 13 | APD | Materials | 0.358 | Event intensity negative |
| 14 | UBER | Industrials | 0.351 | Event intensity negative |
| 15 | AMT | Real Estate | 0.344 | Event intensity negative |
| 16 | VICI | Real Estate | 0.342 | Event intensity negative |
| 17 | GEV | Industrials | 0.336 | Event intensity negative |
| 18 | COST | Consumer Staples | 0.336 | Event intensity negative |
| 19 | HUBB | Industrials | 0.334 | Event intensity negative |
| 20 | APH | Information Technology | 0.329 | Event intensity negative |

## What this is / isn't

**What this report is**
- A systematic scan of weekly news-driven market pressure (UPS/DPS)
- A way to surface information flow shifts you may not have time to track manually
- A starting point for your own due diligence and risk decisions

**What this report is not**
- Investment advice
- A prediction of price movements
- A substitute for portfolio-level risk management

## Build Stamp

For full traceability and reproducibility:

- **Git SHA:** `facf01ed1664...` (full: `facf01ed1664f1a79026492471bf49506badbb23`)
- **GitHub Run:** `21333803441` (attempt 1)
- **features_scores.py SHA256:** `94ef473c17741257...`
- **Python:** 3.11.14
- **Dependencies:** pandas 3.0.0, numpy 2.4.1
