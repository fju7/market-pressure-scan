# Weekly Market Pressure Report
**Week Ending:** 2025-11-20

This report ranks S&P 500 names by **Upside Pressure (UPS)** using weekly news novelty, event intensity, sentiment shift, and market confirmation. Use it as a **screen and context tool**, not as a standalone trading instruction.

## Signal quality snapshot
- Avg novelty (z): 0.00
- Avg event intensity (z): -0.00
- Avg price-action news rate: 0.47
- PRICE_ACTION_RECAP (% of clusters): 36%
- Sector mix (Top 20): Health Care: 3, Consumer Staples: 3, Utilities: 3, Communication Services: 2, Consumer Discretionary: 2, Industrials: 2, Materials: 1, Information Technology: 1, Financials: 1, Real Estate: 1, Energy: 1

## ⚠️ Low-information week
The system is seeing mostly market wrap / price-move recap content rather than company-specific events. Treat UPS/DPS rankings as *low conviction* this week.
- novelty and event intensity are near zero on average

## Top 20 Upside Pressure (UPS)

| Rank | Ticker | Sector | UPS_adj | Conviction | Drivers | Rationale | Signal state |
|---:|:---|:---|---:|:---|:---|:---|:---|
| 1 | VMC | Materials | 0.540 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 2 | GOOGL | Communication Services | 0.538 | Moderate | Event intensity, Sentiment inflection | Ranked primarily due to recent price confirmation rather than new information. | Early |
| 3 | GOOG | Communication Services | 0.522 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 4 | ROST | Consumer Discretionary | 0.517 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 5 | AMAT | Information Technology | 0.508 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 6 | WSM | Consumer Discretionary | 0.501 | Moderate | Event intensity, Sentiment inflection | Ranked due to strong divergence: constructive news signals while recent price action remains weak. | Early |
| 7 | SOLV | Health Care | 0.494 | Moderate | Event intensity, Sentiment inflection | Rank reflects a mix of weaker signals with no clear dominant driver. | Early |
| 8 | GEV | Industrials | 0.478 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 9 | IDXX | Health Care | 0.473 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 10 | BIIB | Health Care | 0.469 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 11 | PEP | Consumer Staples | 0.462 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 12 | URI | Industrials | 0.454 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 13 | SYF | Financials | 0.453 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 14 | CNP | Utilities | 0.447 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 15 | DLR | Real Estate | 0.446 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 16 | HSY | Consumer Staples | 0.443 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 17 | MNST | Consumer Staples | 0.441 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 18 | KMI | Energy | 0.438 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 19 | DUK | Utilities | 0.436 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |
| 20 | PCG | Utilities | 0.436 | Moderate | Event intensity, Sentiment inflection | Ranked due to information-driven news flow with limited price confirmation so far. | Early |

## Stock cards (Top UPS)

### VMC — Materials
- **UPS_adj:** 0.540 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.22 · EVS 1.35 · MCS_up 0.49
- Market context: AR5 3.57% · VS 0.30 · VR_pct 0.22
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **The Bull Case For Vulcan Materials (VMC) Could Change Following Robust Q3 Results and Upbeat Outlook** — Robust Q3 results and an upbeat outlook suggest strong future performance and investor confidence.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### GOOGL — Communication Services
- **UPS_adj:** 0.538 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked primarily due to recent price confirmation rather than new information.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.61
- Market context: AR5 6.81% · VS 0.38 · VR_pct 0.71
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Bitcoin Miner Expands HPC, AI Deal With Fluidstack, Google** — The partnership expansion suggests strategic collaboration and potential revenue growth for involved parties.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### GOOG — Communication Services
- **UPS_adj:** 0.522 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.56
- Market context: AR5 6.80% · VS 0.33 · VR_pct 0.69
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Bitcoin Miner Expands HPC, AI Deal With Fluidstack, Google** — The strategic partnership enhances capabilities in AI and HPC, signaling a positive development for the companies invol…

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### ROST — Consumer Discretionary
- **UPS_adj:** 0.517 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.22 · EVS 1.35 · MCS_up 0.43
- Market context: AR5 2.09% · VS 0.26 · VR_pct 0.21
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Ross Stores (ROST) Beats Q3 Earnings and Revenue Estimates** — Beating earnings and revenue estimates suggests potential for future growth.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### AMAT — Information Technology
- **UPS_adj:** 0.508 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.22 · EVS 1.35 · MCS_up 0.40
- Market context: AR5 1.56% · VS 0.25 · VR_pct 0.88
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **These Stocks Moved the Most Today: Applied Materials, Walmart, Strategy, Warner Bros., and More** — The company forecasted solid results for the upcoming quarter, enhancing investor confidence.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### WSM — Consumer Discretionary
- **UPS_adj:** 0.501 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to strong divergence: constructive news signals while recent price action remains weak.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.50
- Market context: AR5 -4.56% · VS 0.59 · VR_pct 0.73
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **WSM Q3 Deep Dive: AI and Tariff Mitigation Shape Results Amid Mixed Market Reaction** — Q3 results exceeded expectations, reflecting strong operational performance.

**Key risks**
- Unusually high trading volume (attention risk / crowdedness)

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### SOLV — Health Care
- **UPS_adj:** 0.494 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Rank reflects a mix of weaker signals with no clear dominant driver.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.49
- Market context: AR5 8.62% · VS 0.18 · VR_pct 0.55
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **Solventum Announces $1 Billion Share Repurchase Program** — The announcement of a $1 billion share repurchase program is a significant move to return value to shareholders.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### GEV — Industrials
- **UPS_adj:** 0.478 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.19 · EVS 1.26 · MCS_up 0.41
- Market context: AR5 2.88% · VS 0.23 · VR_pct 0.90
- Event tags: `OTHER_LOW_SIGNAL`

**What changed this week**
- **GE Vernova Gains Momentum: Is GEV Stock a Buy Here?** — The article suggests a favorable outlook for GE Vernova's growth prospects.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### IDXX — Health Care
- **UPS_adj:** 0.473 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.43
- Market context: AR5 1.17% · VS 0.33 · VR_pct 0.83
- Event tags: `ANALYST_ACTION`

**What changed this week**
- **How the Story Around IDEXX Is Shifting With Strong Results and New Analyst Targets** — Increased analyst price targets reflect renewed optimism and confidence in IDEXX's future performance.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### BIIB — Health Care
- **UPS_adj:** 0.469 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.41
- Market context: AR5 5.00% · VS 0.20 · VR_pct 0.76
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Biogen to Highlight New Lecanemab Data and Scientific Advances at the 18th Clinical Trials on Alzheimer’s Disease Confe…** — Biogen's presentation at a major conference highlights advancements in Alzheimer's research and treatment.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### PEP — Consumer Staples
- **UPS_adj:** 0.462 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.22 · EVS 1.35 · MCS_up 0.27
- Market context: AR5 3.65% · VS 0.03 · VR_pct 0.24
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Does Celsius Holdings' Buyback Plan Signal Stronger Growth Ahead?** — The buyback plan reflects strategic confidence in future growth and operational strength.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### URI — Industrials
- **UPS_adj:** 0.454 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.22 · EVS 1.35 · MCS_up 0.25
- Market context: AR5 -5.78% · VS 0.28 · VR_pct 0.60
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Dycom Q3 Earnings & Revenues Surpass Estimates, Stock Up** — The earnings beat and improved guidance suggest strong future growth potential.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### SYF — Financials
- **UPS_adj:** 0.453 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.37
- Market context: AR5 0.83% · VS 0.27 · VR_pct 0.49
- Event tags: `PRODUCT_MARKET`

**What changed this week**
- **Synchrony and The Toro Company Launch New Credit Card for Financing Lawn Equipment** — The launch of a new credit card program indicates a strategic partnership that can boost business growth.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Competitive response, contract repricing, or demand weakness

### CNP — Utilities
- **UPS_adj:** 0.447 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.19 · EVS 1.35 · MCS_up 0.27
- Market context: AR5 2.95% · VS 0.06 · VR_pct 0.03
- Event tags: `EARNINGS_GUIDANCE`

**What changed this week**
- **Here's Why AEE Stock Deserves a Place in Your Portfolio Right Now** — The raised outlook reflects confidence in future performance and strategic investments.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Follow-on guidance or margin commentary that contradicts the initial read

### DLR — Real Estate
- **UPS_adj:** 0.446 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.35
- Market context: AR5 2.58% · VS 0.19 · VR_pct 0.49
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Schneider Electric and Digital Realty Announce $373M Supply Capacity Agreement to Meet Rising Data Center Demand** — The supply capacity agreement signifies a strategic partnership to address rising data center demand.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### HSY — Consumer Staples
- **UPS_adj:** 0.443 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.34
- Market context: AR5 5.44% · VS 0.10 · VR_pct 0.47
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Hershey's LesserEvil Buyout to Strengthen Better-for-You Snacks** — The buyout is expected to significantly strengthen Hershey's position in the better-for-you snacks market.

**Key risks**
- Recent sharp move; risk of mean reversion

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### MNST — Consumer Staples
- **UPS_adj:** 0.441 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.22 · EVS 1.35 · MCS_up 0.21
- Market context: AR5 4.52% · VS -0.06 · VR_pct 0.39
- Event tags: `MNA_STRATEGIC`

**What changed this week**
- **Does Celsius Holdings' Buyback Plan Signal Stronger Growth Ahead?** — The buyback plan reflects strategic confidence in future growth and profitability.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- A reversal in news flow (lower novelty) combined with weak price confirmation

### KMI — Energy
- **UPS_adj:** 0.438 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.33
- Market context: AR5 2.31% · VS 0.18 · VR_pct 0.12
- Event tags: `OPERATIONS_SUPPLY`

**What changed this week**
- **Biggest Gas Pipeline Buildout Since 2008 Propels Trump Energy Push** — The significant pipeline buildout enhances operational capacity and supports energy supply in key regions.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Evidence the operational issue is broader or longer-lived than expected

### DUK — Utilities
- **UPS_adj:** 0.436 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.32
- Market context: AR5 2.06% · VS 0.18 · VR_pct 0.01
- Event tags: `CAPITAL_STRUCTURE`

**What changed this week**
- **Duke Energy proposes new investments in North Carolina to boost reliability and support economic growth across the state** — The filing for revised rates indicates a strategic move to improve financial stability.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Higher financing costs, dilution, or covenant stress

### PCG — Utilities
- **UPS_adj:** 0.436 | **Conviction:** Moderate | **Signal state:** Early
- Ranking rationale: Ranked due to information-driven news flow with limited price confirmation so far.
- Components: IFS 0.12 · EVS 1.35 · MCS_up 0.32
- Market context: AR5 -1.90% · VS 0.29 · VR_pct 0.51
- Event tags: `OPERATIONS_SUPPLY`

**What changed this week**
- **Californians Express Overwhelming Support for Undergrounding Powerlines to Reduce Wildfire Risk** — The poll results suggest strong community backing for PG&E's operational strategies to enhance safety.

**Key risks**
- Normal idiosyncratic and market risk

**What would weaken this signal**
- Evidence the operational issue is broader or longer-lived than expected

## Bottom 20 Downside Pressure (DPS) snapshot

| Rank | Ticker | Sector | DPS_adj | Primary concern |
|---:|:---|:---|---:|:---|
| 1 | ES | Utilities | 0.613 | Event intensity negative |
| 2 | SNDK | Information Technology | 0.571 | Event intensity negative |
| 3 | PANW | Information Technology | 0.562 | Event intensity negative |
| 4 | MSI | Information Technology | 0.561 | Event intensity negative |
| 5 | LOW | Consumer Discretionary | 0.558 | Event intensity negative |
| 6 | COF | Financials | 0.552 | Event intensity negative |
| 7 | ETN | Industrials | 0.529 | Event intensity negative |
| 8 | TEL | Information Technology | 0.526 | Event intensity negative |
| 9 | TGT | Consumer Staples | 0.526 | Event intensity negative |
| 10 | PODD | Health Care | 0.520 | Event intensity negative |
| 11 | DASH | Consumer Discretionary | 0.518 | Event intensity negative |
| 12 | UBER | Industrials | 0.506 | Event intensity negative |
| 13 | MCHP | Information Technology | 0.505 | Event intensity negative |
| 14 | EPAM | Information Technology | 0.504 | Event intensity negative |
| 15 | XYL | Industrials | 0.499 | Event intensity negative |
| 16 | COIN | Financials | 0.498 | Event intensity negative |
| 17 | ABT | Health Care | 0.497 | Event intensity negative |
| 18 | MU | Information Technology | 0.495 | Event intensity negative |
| 19 | POOL | Consumer Discretionary | 0.488 | Event intensity negative |
| 20 | CME | Financials | 0.479 | Event intensity negative |

## What this is / isn't

**What this report is**
- A systematic scan of weekly news-driven market pressure (UPS/DPS)
- A way to surface information flow shifts you may not have time to track manually
- A starting point for your own due diligence and risk decisions

**What this report is not**
- Investment advice
- A prediction of price movements
- A substitute for portfolio-level risk management

## Build Stamp

For full traceability and reproducibility:

- **Git SHA:** `356c9b376de0...` (full: `356c9b376de0e0c94a8ff7c838b5fd682ff67877`)
- **GitHub Run:** `21358472085` (attempt 1)
- **features_scores.py SHA256:** `cc6abaaf8c2a089f...`
- **Python:** 3.11.14
- **Dependencies:** pandas 3.0.0, numpy 2.4.1
